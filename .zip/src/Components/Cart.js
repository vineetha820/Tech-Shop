

import React, { useContext } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCartPlus, faTrashAlt } from '@fortawesome/free-solid-svg-icons'; // Updated icon
import "./Cart.css";
import { UserContext } from '../App';
import { Link } from 'react-router-dom';


function Cart() {
  const { cartItems, totalPrice, count, increment, decrement, removeItem,originalPrice,discount,productDetails,changeHeroImage } = useContext(UserContext);

  const handleRemoveItem = (itemId) => {
    removeItem(itemId); // Call the removeItem function from context
  };

  return (
    <>
      {cartItems.length === 0 ? (
        <div className='cart'>
          <h1 className='cart-icon'><FontAwesomeIcon icon={faCartPlus} /></h1> 
          <h1>cart is empty</h1>
          <Link to="/product"><button>start shopping</button></Link> 
        </div>
      ) : (
        <div className='cart-Full'>
          <div>
            {cartItems.map((item, index) => (
              <div key={index} className='cart-card'>
             <Link to="/ProductInfo">  <img src={item.images[0]} alt="images" width={"100%"} onClick={()=>{productDetails(item); changeHeroImage(item.images[0]);}}/></Link>
                <div className='cart-details'>
                  <p>{item.title}{item.info}</p>
                  <p className='Fprice'>₹{item.finalPrice}  <span className='Oprice'><strike>₹{item.originalPrice}</strike></span></p>
                  <div className='quantity'>
                    <button onClick={() => decrement(item.id)}>-</button>
                    <button>{item.quantity}</button>
                    <button onClick={() => increment(item.id)}>+</button>

                  </div>
                </div>
                <button onClick={() => handleRemoveItem(item.id)}><FontAwesomeIcon icon={faTrashAlt} /></button> {/* Call handleRemoveItem with item id */}
              </div>
            ))}
          </div>
          <div>
            <h3>order summery{count} item</h3>
            <div className='cart-summery'>
              <div>
                <p>original price</p>
                <p>discount</p>
                <p>delivery</p>
              </div>
              <div>
                <p>₹{originalPrice}</p>
                <p>₹{discount}</p>
                <p>Free</p>
              </div>
            </div>
            <hr/>
            <p>total price{totalPrice}</p>
            <button>checkout</button>
          </div>
        </div>
      )}
    </>
  );
}

export default Cart;

