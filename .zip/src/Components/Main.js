import {Link}  from "react-router-dom"

import React, { useState } from 'react';
import productsData from './ProductDetails';
import Structure from './structure';


function Main() {
  const [selectedCategory, setSelectedCategory] = useState('All');

  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
  };

  return (
    <>
      <div className='categories'>
        <button className={selectedCategory === 'All' ? 'active' : ''} onClick={() => handleCategoryChange('All')}>All</button>
        <button className={selectedCategory === 'Headphones' ? 'active' : ''} onClick={() => handleCategoryChange('Headphones')}>Headphones</button>
        <button className={selectedCategory === 'Earbuds' ? 'active' : ''} onClick={() => handleCategoryChange('Earbuds')}>Earbuds</button>
        <button className={selectedCategory === 'Earphones' ? 'active' : ''} onClick={() => handleCategoryChange('Earphones')}>Earphones</button>
        <button className={selectedCategory === 'Neckbands' ? 'active' : ''} onClick={() => handleCategoryChange('Neckbands')}>Neckbands</button>
        {/* Add more buttons for other categories if needed */}
      </div>
      <div className='container1'>
        {productsData
          .filter(item => selectedCategory === 'All' || item.category === selectedCategory)
          .map((item, index) => (
            <Structure key={index} item={item} />
          ))}
       <Link to="/product"> <h1>browse all products</h1></Link>
      </div>
    </>
  );
}

export default Main;



