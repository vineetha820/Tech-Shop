import React from 'react'
import Main from './Main'

function TechShop() {
  return (
    <div>
      <Main/>
    </div>
  )
}

export default TechShop
