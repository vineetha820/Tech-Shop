import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTimes } from "@fortawesome/free-solid-svg-icons";

function UserProfile({ handleRemoveClick }) {
  const [showEmailInput, setShowEmailInput] = useState(false);
  const [showCreateAccount, setShowCreateAccount] = useState(false);

  const handleSignUpClick = () => {
    setShowEmailInput(true);
  };

  const handleCreateAccountClick = () => {
    setShowCreateAccount(true);
  };

  return (
    <div className="signup-container">
    <div className="sign-up-section">
      {showCreateAccount ? (
        <form className="signup-form">
          <FontAwesomeIcon icon={faTimes} className="remove-icon" onClick={handleRemoveClick} />
          <h2>Signup</h2>
          <p>Already have an account? login</p>
          
          <input type="text" placeholder="Username" id="form_data"/><br />
          <input type="email" placeholder="Email" id="form_data"/><br />
          <input type="password" placeholder="Password" id="form_data" /><br />
          <input type="password" placeholder="Conform Password" id="form_data"/><br />
          <button id="form_signup_btn">SignUp</button>
          
          <p>or login with</p>
          <div id="form_btn">
            <button id="facebook_btn">Facebook</button>
            <button  id="google_btn">Google</button>
            <button id="twiter-btn">Twitter</button>
          </div>
        </form>
      ) : (
        showEmailInput ? (
          <form className="login-form">
            <FontAwesomeIcon icon={faTimes} className="remove-icon" onClick={handleRemoveClick} />
            <h3>Login</h3>
            <p>New to PRAVALIKA GORANTLA? <span onClick={handleCreateAccountClick}>Create an account</span></p>
            <input type="email" placeholder="Email"id="form_data" /><br />
            <input type="password" placeholder="Password" id="form_data"/><br />
            <button>Login</button>
            <p>or login with</p>
            <div id="form_btn">
              <button id="facebook_btn">Facebook</button>
              <button  id="google_btn">Google</button>
              <button id="twiter-btn">Twitter</button>
            </div>
          </form>
        ) : (
          <>
            <div id="form_1">
              <h3>Hello!</h3>
              <p id="form_desc">Access account and manage order</p>
              <button id="login_signup_btn" onClick={handleSignUpClick}>Login/Sign Up</button>
              <hr />
              <p>Please Login</p>
            </div>
          </>
        )
      )}
    </div>
    </div>
  );
}

export default UserProfile;
